import { animate, state, style, transition, trigger } from '@angular/animations';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';


const fadeInOut = trigger('fadeInOut', [
  state(
    'in',
    style({
      opacity: 1,
    })
  ),
  transition('void => *', [style({ opacity: 0 }), animate('1s ease-out')]),
  transition('* => void', [animate('1s ease-out'), style({ opacity: 0 })]),
]);

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss'],
  animations: [fadeInOut]
})
export class ProductsComponent implements OnInit {
  showProductDetails = false;
  showChatBot = false;
  constructor(
    private http: HttpClient

  ) { }

  ngOnInit(): void {
    // const headerDict = {
    //   'Accept': 'application/json',
    //   'Access-Control-Allow-Headers': '*',
    //   'Access-Control-Allow-Origin': '*'
    // }
    
    // const requestOptions = {                                                                                                                                                                                 
    //   headers: new HttpHeaders(headerDict), 
    // };
    
    // // return this.http.get(this.heroesUrl, requestOptions)

    // this.http.get('http://localhost:3000/', requestOptions).subscribe((val) => console.log(val));
  }

  productSelected() {
    this.showProductDetails = true;
  }

  navigateToQueries() {
    console.log('clicked');
    this.showChatBot = true;
  }

  previousPage($event) {
    this.showChatBot = !$event;
    console.log($event);
  }

}
